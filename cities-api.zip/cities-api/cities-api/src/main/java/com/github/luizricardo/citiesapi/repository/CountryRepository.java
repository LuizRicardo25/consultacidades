package com.github.luizricardo.citiesapi.repository;

import com.github.luizricardo.citiesapi.countries.Country;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;

import java.awt.print.Pageable;

public interface CountryRepository extends JpaRepository <Country, Long> {

    Page<Country> findAll(Pageable page);
}
